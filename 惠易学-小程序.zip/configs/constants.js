module.exports = {
    APPPROXY_API: "https://gznspower.cn",
    APP_API: "https://huiyixue.hby.sn.cn",
    ACCOUNT: "WAC010",
    APPNAME: "电力安规理论练习",
    DEFAULT_IMAGE: "//res.viewlayer.cn/ebiz/mallv5/default.svg",
    DEFAULT_MTAG: "5a2fd01e74691581777405",
    "404_MTAG": "5b0c0e47ba1c9267672284",
    QRCODE_404: "LOGIN_PRIVILEGE",
    "404_URL": "LOGIN_PRIVILEGE",
    MTA_APPID: "500612647",
    MTA_EVENTID: "500612756",
    CUSTOMER_SERVICE_PRODUCTS_LISTS: [],
    CUSTOMER_SERVICE_HOUR: [ 9, 23 ],
    CUSTOMER_SERVICE_MTAG: "5afd102540c45268626002"
};