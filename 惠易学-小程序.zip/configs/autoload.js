module.exports = {
    libs: [ "initial", "events", "page", "schemes", "polyfill", "navigation", "request", "formids", "token", "commander", "mta", "component", "users" ],
    configs: [ "constants", "routes" ]
};