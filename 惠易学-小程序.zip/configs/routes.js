module.exports = {
    INDEX: "/pages/index/index",
    HOME: "/pages/home/index",
    PERSONAL: "/pages/personal_center/index",
    QIPAN: "/pages/qiPan/index",
    LOGIN: "/pages/login/index",
    TRO: "/pages/tro/index",
    COMPANY: "/pages/company/index",
    NEW_HOME: "/pages/new_home/index"
};