var r = require("../@babel/runtime/helpers/createForOfIteratorHelper"), e = require("../configs/autoload");

module.exports = function(t) {
    var a = {};
    for (var o in e) {
        a[o] = {};
        var n, c = r(e[o]);
        try {
            for (c.s(); !(n = c.n()).done; ) {
                var u = n.value, i = require("../".concat(o, "/").concat(u));
                a[o][u] = "function" == typeof i ? new i(t) : i;
            }
        } catch (r) {
            //r = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(r);
            c.e(r);
        } finally {
            c.f();
        }
    }
    return a;
};