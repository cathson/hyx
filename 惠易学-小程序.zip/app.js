const utils = require("./utils/utils")
App({
    
    onLaunch: function(t) {
        
        //this.libs = this.autoload.libs, 
        //this.configs = this.autoload.configs, 
        this.globalData.systeminfo = wx.getSystemInfoSync(), 
        this.globalData.openid = wx.getStorageSync("openid") ? wx.getStorageSync("openid") : "";
    },
    onShow: function(t) {
        
    },
    Page: function(t) {
        this.libs.page.page(t);
    },
    Component: function(t) {
        this.libs.component.component(t);
    },
    globalData: {
        formids: [],
        events: [],
        modal_festival: !0,
        appLaunchStat: 0,
        systeminfo: null,
        querydata: {}
    }
});