Page({
    data: {},
    onLoad() {
        //this.setData({src: decodeURIComponent(options.src)})
     },
     
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});