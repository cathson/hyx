const app = getApp();

Page({
    data: {
        wxCode: "",
        isShow: 0
    },
    onLoad: function (o) {
        console.log("index====onLoad======" + o.isShow)
        this.setData({
            isShow: Number(o.isShow)
        });
    },
    onReady: function () {},
    onShow: function () {
        console.log("code in 20240329=====001")
    },
    wxLogin: function () {
        var o = this;
        wx.login({
            success: function (n) {
                o.setData({
                    wxCode: n.code
                })
                o.checkLogin();
            }
        });
    },
    lianjietiaozhuan: function() {
        console.log("lianjietiaozhuan")
        wx.navigateTo({
            url: '/pages/web/index'
        })
    },
    checkLogin: function () {
        wx.showLoading({
            title: "登录中",
            mask: true
        });
        var n = {
            jscode: this.data.wxCode
        };
        //console.log("APP_API====="+o.configs.constants.APP_API)
        console.log("wxCode====" + this.data.wxCode)
        //console.log("request"+o.libs.request)

        wx.request({
            url: "https://huiyixue.hby.sn.cn/api/checklogin",
            data: n,
            method: 'post',
            success: function (result) {
                wx.hideLoading();
                if (result.data.ret === 0) {
                    console.log("openId====" + result.data.data.openId)
                    wx.setStorageSync('openid', result.data.data.openId);
                    app.globalData.openid = result.data.data.openId;
                    console.log("登录====data===")
                    console.log(result.data.data)
                    if (result.data.data.isLogin === 0) {
                        //app.libs.navigation.reLaunch({
                            //key: "LOGIN",
                            //data: {}
                        //});
                        console.log("登录====data===没有注册")
                        wx.reLaunch({
                            url: "/pages/login/index",
                        })
                    } else {
                        console.log("登录====data===已经注册")
                        wx.reLaunch({
                            url: '/pages/home/index',
                        })
                        //wx.reLaunch({
                            //url: "/pages/login/index",
                        //})
                    }
                } else {
                    console.log("登录====data===自动登录失败")
                    wx.showToast({
                        title: "自动登录失败",
                        icon: "none",
                    });
                    wx.reLaunch({
                        url: '/pages/login/index'
                    })
                }
            },
            fail: function (o) {
                wx.hideLoading();
            }
        });
    },
    handleStart: function () {
        this.wxLogin();
    }
});