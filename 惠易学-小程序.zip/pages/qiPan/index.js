var t = require("../../@babel/runtime/helpers/slicedToArray"), a = (getApp(), require("../../utils/lunar_transform.js")), n = require("../../utils/qipan.js"), e = function(t) {
    return (t = t.toString())[1] ? t : "0" + t;
}, r = new Array("零", "一", "二", "三", "四", "五", "六", "七", "八", "九"), o = function(t) {
    var a = "";
    t = t.toString();
    for (var n = 0; n < t.length; n++) {
        var e = t[n];
        a += r[e];
    }
    return a + "年";
};

Page({
    data: {
        currentSolunarDateStr: "",
        currentLunarDateStr: "",
        currentTimeStr: "",
        sexValue: "1",
        lunarInitDate: "",
        showLunarDatePicker: !1,
        gongIndexData: [ 4, 9, 2, 3, 5, 7, 8, 1, 6 ],
        drawData: {},
        yiMaIndex: null,
        yiMaClass: "",
        kongWangIndex: null,
        kongWangClass: ""
    },
    onLoad: function(t) {
        var a = t.lunarDate, n = t.lunarInitDate, e = t.currentDate, r = t.currentTime, o = t.sexValue;
        this.setData({
            currentSolunarDateStr: e,
            currentLunarDateStr: a,
            currentTimeStr: r,
            lunarInitDate: n,
            sexValue: o
        }), this.getData();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    getData: function() {
        var a = this.data.currentSolunarDateStr, e = this.data.currentTimeStr, r = a.split("-"), o = t(r, 3), i = o[0], u = o[1], s = o[2], c = e.split(":"), l = t(c, 2), D = l[0], g = l[1], h = n(i, u, s, D, g);
        console.log(h);
        var S = h.yiMaXing, d = null, f = "";
        "申" == S ? (d = 2, f = "right") : "亥" == S ? (d = 8, f = "bottom") : "寅" == S ? (d = 6, 
        f = "left") : "巳" == S && (d = 0, f = "top");
        var p = null, v = "", I = h.kongWangData;
        "辰" == I[0] ? (p = 0, v = "top") : "午" == I[0] ? (p = 2, v = "top") : "寅" == I[0] ? (p = 6, 
        v = "top") : "申" == I[0] ? (p = 2, v = "bottom") : "子" == I[0] ? (p = 6, v = "bottom") : "戌" == I[0] && (p = 8, 
        v = "bottom"), this.setData({
            drawData: h,
            yiMaIndex: d,
            yiMaClass: f,
            kongWangIndex: p,
            kongWangClass: v
        });
    },
    getLunarDate: function(t) {
        var n = t.split("-"), e = a.toLunar(parseInt(n[0]), parseInt(n[1]), parseInt(n[2]));
        if (console.log("lunar==", e), e.length > 6) {
            var r = e[1], i = "".concat(e[0], "-").concat(r, "-").concat(e[2]), u = "".concat(o(e[0])).concat(e[5]).concat(e[6]);
            this.setData({
                lunarInitDate: i,
                currentLunarDateStr: u
            });
        }
    },
    getSolunarDate: function(n) {
        var r = t(n, 3), o = r[0], i = r[1], u = r[2], s = [ parseInt(o + 1910), parseInt(i + 1), parseInt(u + 1) ], c = a.toSolar(s[0], s[1], s[2]), l = t(c, 3), D = l[0], g = l[1], h = l[2];
        g = e(g), h = e(h), this.setData({
            currentSolunarDateStr: "".concat(D, "-").concat(g, "-").concat(h)
        });
    },
    handleShowLunarDate: function() {
        this.setData({
            showLunarDatePicker: !0
        });
    },
    bindLunarDateChange: function(t) {
        var a = t.detail.dateStr.split(")"), n = o(a[0].split("(")[0]);
        this.getSolunarDate(t.detail.dateIndex), this.setData({
            currentLunarDateStr: n + a[1]
        })
        this.getData();
    },
    bindDateChange: function(t) {
        var a = t.detail.value;
        this.getLunarDate(a);
        this.setData({
            currentSolunarDateStr: a
        })
        this.getData();
    },
    bindTimeChange: function(t) {
        var a = t.detail.value;
        this.setData({
            currentTimeStr: a
        })
        this.getData();
    }
});