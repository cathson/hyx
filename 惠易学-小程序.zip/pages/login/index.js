var e = getApp();

Page({
    data: {
        mobile: "",
        referrer_mobile: "13544173945"
    },
    onLoad: function(e) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    valueChange: function(e) {
        this.setData({
            mobile: e.detail.value
        })
    },
    checkForm: function() {
        var e = this.data, t = e.mobile, o = e.referrer_mobile;
        return /^1(3|4|5|6|7|8|9)\d{9}$/.test(t) ? !!/^1(3|4|5|6|7|8|9)\d{9}$/.test(o) || (wx.showToast({
            title: "您输入的手机号有误",
            icon: "none"
        }), !1) : (wx.showToast({
            title: "您输入的手机号有误",
            icon: "none"
        }), !1);
    },
    doLoginByPsw: function() {
        console.log("doLoginByPsw====11111")
        
        if (!this.checkForm()) return !1;
        wx.showLoading({
            title: "登录中",
            mask: !0
        });
        wx.request({
            url: "https://huiyixue.hby.sn.cn/api/normallogin",
            data: {
                openid: wx.getStorageSync('openid'),
                mobile: this.data.mobile,
                referrer_mobile: this.data.referrer_mobile
            },
            method: 'post',
            success: function(t) {
                console.log("login=====success===="+t.data)
                if (-1 == t.data.ret){
                    console.log("login====失败====" + t.data.msg)
                    wx.showModal({
                        title: "提示",
                        content: t.data.msg
                    })
                }else{
                    console.log("login====注册成功")
                    wx.reLaunch({
                        url: '/pages/home/index'
                    })
                }
            },
            complete: function() {
                wx.hideLoading();
            }
        });
    }
});