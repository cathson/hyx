Page({
    data: {},
    onLoad: function(n) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    lianjietiaozhuan: function() {
        console.log("lianjietiaozhuan")
        wx.navigateTo({
            url: '/pages/web/index'
        })
    },
    onShareAppMessage: function() {}
});