var n = getApp();

Page({
    data: {
        isReview: !1
    },
    onLoad: function(n) {
        this.getReviewStatus();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    handleGoIntro: function() {
        wx.navigateTo({
            url: '/pages/company/index'
        })
    },
    handleGoQiPan: function() {
        //var t = this.data.isReview ? 0 : 1;
        wx.navigateTo({
            url: '/pages/index/index?isShow=' + this.data.isReview
        })
    },
    handleGoCiShan: function() {
        wx.navigateTo({
            url: '/pages/tro/index'
        })
    },
    lianjietiaozhuan: function() {
        console.log("lianjietiaozhuan")
        wx.navigateTo({
            url: '/pages/web2/index'
        })
    },
    getReviewStatus: function() {
        var t = this;
        /*n.libs.request.post({
            url: n.configs.constants.APP_API + "/api/",
            data: {},
            success: function(n) {
                if (console.log("result2=="), console.log(n), 0 === n.ret) {
                    var a = 2 != (n.data ? n.data : 2);
                    t.setData({
                        isReview: a
                    });
                }
            }
        });*/

        wx.request({
            url: "https://huiyixue.hby.sn.cn/api/reviewstatus",
            data: {
                openid: wx.getStorageSync('openid')
            },
            method: 'post',
            success: function (result) {
                wx.hideLoading();
                console.log("result=="+result)
                console.log("result.ret=="+result.data.ret)
                if (result.data.ret === 0) {
                    console.log("data=="+result.data.data)
                    t.setData({
                        isReview: result.data.data
                    });
                }
            }
        });
    }
});