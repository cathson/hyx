var t = getApp();

Page({
    data: {
        userinfo: {
            avatarUrl: "/dist/images/icon_default_header.png",
            nickName: ""
        },
        isLogin: !1,
        show_madal: !1,
        feedback_text: ""
    },
    onLoad: function(n) {
        var o = this;
        t.libs.users.getUserInfo().then(function(t) {
            o.setData({
                userinfo: t.data,
                isLogin: !0
            });
        }, function(t) {
            o.setData({
                isLogin: !1
            });
        });
    },
    onShareAppMessage: function() {
        var n = t.configs.routes.HOME;
        return {
            title: t.configs.constants.APPNAME,
            path: n
        };
    },
    tapGetUserInfo: function(n) {
        var o = this, e = n.detail;
        t.libs.users.saveUserInfo(e).then(function(t) {
            o.setData({
                userinfo: t.data.userinfo,
                isLogin: !0
            });
        }, function(t) {
            var n = t || "您取消了授权";
            wx.showToast({
                title: n
            });
        });
    },
    getUserInfo: function(n) {
        var o = wx.getStorageSync("userinfo");
        if (o) return n({
            data: o
        }), !1;
        wx.getSetting({
            success: function(o) {
                o.authSetting["scope.userInfo"] && t.libs.users.getUserInfo().then(function(t) {
                    "function" == typeof n && n(t);
                }).catch(function(t) {
                    console.log(t);
                });
            },
            fail: function() {
                wx.showToast({
                    title: "您取消了授权"
                });
            }
        });
    },
    handleLogout: function(t) {
        this.setData({
            userinfo: {
                avatarUrl: "/dist/images/icon_default_header.png",
                nickName: ""
            },
            isLogin: !1
        });
    },
    submitFeedback: function(n) {
        var o = this;
        wx.showLoading({
            title: "提交中..."
        });
        var e = {
            content: this.data.feedback_text
        };
        t.libs.request.post({
            url: t.configs.constants.APP_API + "/api/suggestion",
            data: e,
            success: function(t) {
                o.setData({
                    show_madal: !1,
                    feedback_text: ""
                }), wx.showToast({
                    title: "反馈成功",
                    icon: "success",
                    duration: 2e3
                });
            },
            complete: function() {
                wx.hideLoading();
            }
        });
    },
    onAdplay: function(t) {
        console.log("onAdplay", t);
    },
    onAdload: function(t) {
        console.log("onAdload", t);
    },
    onAdclose: function(t) {
        console.log("onAdclose", t);
    },
    onAdError: function(t) {
        console.log("onAdError", t);
    }
});