var t = require("../../@babel/runtime/helpers/slicedToArray"),
    a = getApp(),
    e = require("../../utils/lunar_transform.js"),
    n = function (t) {
        return [t.getHours(), t.getMinutes()].map(i).join(":");
    },
    i = function (t) {
        return (t = t.toString())[1] ? t : "0" + t;
    },
    o = new Array("零", "一", "二", "三", "四", "五", "六", "七", "八", "九"),
    s = function (t) {
        var a = "";
        t = t.toString();
        for (var e = 0; e < t.length; e++) {
            var n = t[e];
            a += o[n];
        }
        return a + "年";
    };

Page({
    data: {
        date: "",
        time: "12:01",
        sexItems: [{
            value: "1",
            name: "男",
            checked: !0
        }, {
            value: "2",
            name: "女"
        }],
        sexValue: "1",
        lunarDate: "",
        lunarInitDate: "",
        showLunarDatePicker: !1
    },
    onLoad: function (t) {
        var a, e = [(a = new Date()).getFullYear(), a.getMonth() + 1, a.getDate()].map(i).join("-");
        this.getLunarDate(e), this.setData({
            date: e,
            time: n(new Date())
        });
    },
    onReady: function () {},
    onShow: function () {},
    onHide: function () {},
    onUnload: function () {},
    onPullDownRefresh: function () {},
    onReachBottom: function () {},
    onShareAppMessage: function () {},
    getLunarDate: function (t) {
        var a = t.split("-"),
            n = e.toLunar(parseInt(a[0]), parseInt(a[1]), parseInt(a[2]));
        if (console.log("lunar==", n), n.length > 6) {
            var i = n[1],
                o = "".concat(n[0], "-").concat(i, "-").concat(n[2]),
                r = "".concat(s(n[0])).concat(n[5]).concat(n[6]);
            this.setData({
                lunarInitDate: o,
                lunarDate: r
            });
        }
    },
    getSolunarDate: function (a) {
        var n = t(a, 3),
            o = n[0],
            s = n[1],
            r = n[2],
            u = [parseInt(o + 1910), parseInt(s + 1), parseInt(r + 1)],
            c = e.toSolar(u[0], u[1], u[2]),
            l = t(c, 3),
            h = l[0],
            d = l[1],
            g = l[2];
        d = i(d), g = i(g), this.setData({
            date: "".concat(h, "-").concat(d, "-").concat(g)
        });
    },
    bindDateChange: function (t) {
        var a = t.detail.value;
        this.getLunarDate(a), this.setData({
            date: a
        });
    },
    bindRadioChange: function (t) {
        for (var a = this.data.sexItems, e = t.detail.value, n = 0, i = a.length; n < i; ++n) a[n].checked = a[n].value === e;
        this.setData({
            sexItems: a,
            sexValue: e
        });
    },
    bindLunarDateChange: function (t) {
        var a = t.detail.dateStr.split(")"),
            e = s(a[0].split("(")[0]);
        this.getSolunarDate(t.detail.dateIndex), this.setData({
            lunarDate: e + a[1]
        });
    },
    handleShowLunarDate: function () {
        this.setData({
            showLunarDatePicker: !0
        });
    },
    handleStart: function () {
        this.checkUse();
    },
    startUse: function () {
        var t = this.data,
            e = t.date,
            n = t.lunarDate,
            i = t.time,
            o = t.lunarInitDate,
            s = t.sexValue;
        wx.navigateTo({
            url: '/pages/qiPan/index?currentDate=' + e + "&lunarDate=" + n + "&lunarInitDate=" + o + "&currentTime=" + i + "&sexValue=" + s
        })

        /*wx.({
            key: "QIPAN",
            data: {
                currentDate: e,
                lunarDate: n,
                lunarInitDate: o,
                currentTime: i,
                sexValue: s
            }
        });*/
    },
    bindTimeChange: function (t) {
        var a = t.detail.value;
        this.setData({
            time: a
        });
    },
    checkUse: function () {
        wx.showLoading({
            title: "加载中",
            mask: true
        });
        var t = this;
        wx.request({
            url: "https://huiyixue.hby.sn.cn/api/checkuse",
            data: {
                openid: wx.getStorageSync('openid')
            },
            method: 'post',
            success: function (result) {
                wx.hideLoading();
                console.log("result=="+result)
                console.log("result.ret=="+result.data.ret)
                if (result.data.ret === 0) {
                    console.log("status=="+result.data.data.status)
                    if (result.data.data.status == 0) {
                        console.log("不可以使用")
                        wx.showToast({
                            title: "暂无体验权限，请联系管理员！",
                            icon: "none",
                        });
                    } else {
                        // 可以使用
                        console.log("可以使用")
                        t.startUse();
                    }
                } else {
                    wx.showToast({
                        title: result.msg ? result.msg : "自动登录失败",
                        icon: "none",
                    });
                    wx.navigateTo({
                        url: '/pages/login/index'
                    })
                }
            }
        });
    },
    handleGoLingFa: function () {
        wx.navigateToMiniProgram({
            appId: "wx1bb56b08aca9b59f",
            path: "",
            extraData: {
                foo: "bar"
            },
            envVersion: "release",
            success: function (t) {}
        });
    }
});