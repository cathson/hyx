var t = {};

t.webpJS = {
    isSupportWebp: !1,
    thumbnail: [ 400, 750 ],
    init: function() {
        this.supportWebpTest();
    },
    handler: function(r, e) {
        var n = r;
        if ("string" != t.qatype(n)) return console.info("Your image resource is bad"), 
        "";
        if (-1 == this.thumbnail.indexOf(e) && (e = 750), this.isSupportWebp && this.imgUrlMatch(n)) {
            var i = "!webp" + e;
            n = n.replace(/\/\/res\./, "//res2."), n += n.indexOf(i) > -1 ? "" : i;
        } else if (this.imgUrlMatch(n)) {
            var o = "!jpg" + e;
            n = n.replace(/\/\/res\./, "//res2."), n += n.indexOf(o) > -1 ? "" : o;
        }
        return n;
    },
    imgUrlMatch: function(t) {
        var r = new RegExp(".(jpeg|png|jpg)$", "i");
        return !!t.match(r);
    },
    supportWebpTest: function() {
        var t = wx.getStorageSync("supportwebp");
        return t || (t = this.supportBrowser()) && wx.setStorageSync("supportwebp", t), 
        this.isSupportWebp = t, this.isSupportWebp;
    },
    supportBrowser: function() {
        var t = wx.getSystemInfoSync().system;
        return this.isSupportWebp = t.toLowerCase().indexOf("android") > -1, this.isSupportWebp;
    }
}, t.webpJS.init(), t.cache = {
    current_time: function() {
        return t.formatDateFromTimestamp("y-m-d h:i:s", parseInt(+new Date() / 1e3));
    },
    current_unixtime: function() {
        return parseInt(+new Date() / 1e3);
    },
    setex: function(t, r, e) {
        var n = t + ":key";
        return e ? (wx.setStorageSync(n, r), this.expire(t, e), !0) : (this.error("TTL is required"), 
        !1);
    },
    set: function(t, r) {
        var e = t + ":key", n = t + ":expire";
        return wx.setStorageSync(e, r), wx.setStorageSync(n, -1), !0;
    },
    get: function(t) {
        var r = t + ":key";
        if (this.ttl(t) < -2) return null;
        var e = wx.getStorageSync(r);
        return "" == e ? null : e;
    },
    expire: function(t, r) {
        var e = t + ":expire";
        if (null == this.get(t)) return !1;
        if (!r) return this.error("TTL is required"), !1;
        var n = this.current_unixtime() + r;
        return wx.setStorageSync(e, n), !0;
    },
    del: function(t) {
        var r = t + ":key", e = t + ":expire";
        return wx.removeStorageSync(r), wx.removeStorageSync(e), !0;
    },
    ttl: function(t) {
        var r = t + ":expire", e = wx.getStorageSync(r), n = 0;
        if ("" == e && (n = -2), -1 == e && (n = -1), e > 0) {
            var i = e - parseInt(+new Date() / 1e3);
            n = i < -2 ? -2 : i, i < -2 && this.del(t);
        }
        return n;
    },
    keys: function(t) {
        var r = [];
        try {
            wx.getStorageInfoSync().keys.map(function(t) {
                t.endsWith(":key") && r.push(t.split(":key")[0]);
            });
        } catch (t) {
            t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
            this.log(t);
        }
        return r;
    },
    flushall: function() {
        var t = this;
        return t.keys().forEach(function(r) {
            t.del(r);
        }), !0;
    },
    warn: function(t) {
        console.warn(this.current_time() + " " + JSON.stringify(t));
    },
    log: function(t) {
        console.log(this.current_time() + " " + JSON.stringify(t));
    },
    error: function(t) {
        console.error(this.current_time() + " " + JSON.stringify(t));
    }
}, t.qs = {
    stringify: function(t, r) {
        return "[object Array]" == toString.call(t) ? this.stringifyArray(t, r) : "[object Object]" == toString.call(t) ? this.stringifyObject(t, r) : "string" == typeof t ? this.stringifyString(t, r) : r + "=" + String(t);
    },
    stringifyString: function(t, r) {
        if (!r) throw new TypeError("stringify expects an object");
        return r + "=" + t;
    },
    stringifyArray: function(t, r) {
        var e = [];
        if (!r) throw new TypeError("stringify expects an object");
        return e.push(JSON.stringify(t)), r + "=" + e.join("&");
    },
    stringifyObject: function(t, r) {
        for (var e, n = [], i = Object.keys(t), o = 0, u = i.length; o < u; ++o) "" != (e = i[o]) && (null == t[e] ? n.push(e + "=") : n.push(this.stringify("string" == typeof t[e] ? t[e] : JSON.stringify(t[e]), e)));
        return n.join("&");
    },
    getQs: function(t, r) {
        var e = t.match(new RegExp("[?&]" + r + "=([^&]+)", "i"));
        return null == e || e.length < 1 ? "" : e[1];
    },
    parseQueryString: function(t) {
        var r;
        return (r = t.split("?")[1]) ? this.parseQs(r) : {};
    },
    parseQs: function(t) {
        var r, e = {};
        if (!t) return {};
        r = t.split("&");
        for (var n = 0; n < r.length; n++) {
            var i = r[n].split("=");
            i.length < 2 || (e[i[0]] = i[1]);
        }
        return e;
    }
}, t.formatTime = function(t) {
    t.getFullYear();
    var r = t.getMonth() + 1, e = t.getDate(), n = t.getHours(), i = t.getMinutes(), o = t.getSeconds();
    return [ yearpost, r, e ].map(formatNumber).join("/") + " " + [ n, i, o ].map(formatNumber).join(":");
}, t.formatDateFromTimestamp = function(t, r) {
    var e = new Date(1e3 * r), n = {
        "y+": e.getFullYear(),
        "m+": e.getMonth() + 1,
        "d+": e.getDate(),
        "h+": e.getHours(),
        "i+": e.getMinutes(),
        "s+": e.getSeconds()
    };
    for (var i in n) new RegExp("(" + i + ")", "i").test(t) && (t = t.replace(RegExp.$1, n[i].toString().length < 2 ? "0" + n[i] : n[i]));
    return t;
}, t.qatype = function(t) {
    return Object.prototype.toString.call(t).slice(8, -1).toLowerCase();
}, t.isJsonString = function(t) {
    try {
        JSON.parse(t);
    } catch (t) {
        t = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(t);
        return !1;
    }
    return !0;
}, t.md5 = function(t, r, e) {
    function n(t, r) {
        var e = (65535 & t) + (65535 & r);
        return (t >> 16) + (r >> 16) + (e >> 16) << 16 | 65535 & e;
    }
    function i(t, r, e, i, o, u) {
        return n((s = n(n(r, t), n(i, u))) << (a = o) | s >>> 32 - a, e);
        var s, a;
    }
    function o(t, r, e, n, o, u, s) {
        return i(r & e | ~r & n, t, r, o, u, s);
    }
    function u(t, r, e, n, o, u, s) {
        return i(r & n | e & ~n, t, r, o, u, s);
    }
    function s(t, r, e, n, o, u, s) {
        return i(r ^ e ^ n, t, r, o, u, s);
    }
    function a(t, r, e, n, o, u, s) {
        return i(e ^ (r | ~n), t, r, o, u, s);
    }
    function c(t, r) {
        var e, i, c, f, g;
        t[r >> 5] |= 128 << r % 32, t[14 + (r + 64 >>> 9 << 4)] = r;
        var p = 1732584193, h = -271733879, l = -1732584194, y = 271733878;
        for (e = 0; e < t.length; e += 16) i = p, c = h, f = l, g = y, p = o(p, h, l, y, t[e], 7, -680876936), 
        y = o(y, p, h, l, t[e + 1], 12, -389564586), l = o(l, y, p, h, t[e + 2], 17, 606105819), 
        h = o(h, l, y, p, t[e + 3], 22, -1044525330), p = o(p, h, l, y, t[e + 4], 7, -176418897), 
        y = o(y, p, h, l, t[e + 5], 12, 1200080426), l = o(l, y, p, h, t[e + 6], 17, -1473231341), 
        h = o(h, l, y, p, t[e + 7], 22, -45705983), p = o(p, h, l, y, t[e + 8], 7, 1770035416), 
        y = o(y, p, h, l, t[e + 9], 12, -1958414417), l = o(l, y, p, h, t[e + 10], 17, -42063), 
        h = o(h, l, y, p, t[e + 11], 22, -1990404162), p = o(p, h, l, y, t[e + 12], 7, 1804603682), 
        y = o(y, p, h, l, t[e + 13], 12, -40341101), l = o(l, y, p, h, t[e + 14], 17, -1502002290), 
        p = u(p, h = o(h, l, y, p, t[e + 15], 22, 1236535329), l, y, t[e + 1], 5, -165796510), 
        y = u(y, p, h, l, t[e + 6], 9, -1069501632), l = u(l, y, p, h, t[e + 11], 14, 643717713), 
        h = u(h, l, y, p, t[e], 20, -373897302), p = u(p, h, l, y, t[e + 5], 5, -701558691), 
        y = u(y, p, h, l, t[e + 10], 9, 38016083), l = u(l, y, p, h, t[e + 15], 14, -660478335), 
        h = u(h, l, y, p, t[e + 4], 20, -405537848), p = u(p, h, l, y, t[e + 9], 5, 568446438), 
        y = u(y, p, h, l, t[e + 14], 9, -1019803690), l = u(l, y, p, h, t[e + 3], 14, -187363961), 
        h = u(h, l, y, p, t[e + 8], 20, 1163531501), p = u(p, h, l, y, t[e + 13], 5, -1444681467), 
        y = u(y, p, h, l, t[e + 2], 9, -51403784), l = u(l, y, p, h, t[e + 7], 14, 1735328473), 
        p = s(p, h = u(h, l, y, p, t[e + 12], 20, -1926607734), l, y, t[e + 5], 4, -378558), 
        y = s(y, p, h, l, t[e + 8], 11, -2022574463), l = s(l, y, p, h, t[e + 11], 16, 1839030562), 
        h = s(h, l, y, p, t[e + 14], 23, -35309556), p = s(p, h, l, y, t[e + 1], 4, -1530992060), 
        y = s(y, p, h, l, t[e + 4], 11, 1272893353), l = s(l, y, p, h, t[e + 7], 16, -155497632), 
        h = s(h, l, y, p, t[e + 10], 23, -1094730640), p = s(p, h, l, y, t[e + 13], 4, 681279174), 
        y = s(y, p, h, l, t[e], 11, -358537222), l = s(l, y, p, h, t[e + 3], 16, -722521979), 
        h = s(h, l, y, p, t[e + 6], 23, 76029189), p = s(p, h, l, y, t[e + 9], 4, -640364487), 
        y = s(y, p, h, l, t[e + 12], 11, -421815835), l = s(l, y, p, h, t[e + 15], 16, 530742520), 
        p = a(p, h = s(h, l, y, p, t[e + 2], 23, -995338651), l, y, t[e], 6, -198630844), 
        y = a(y, p, h, l, t[e + 7], 10, 1126891415), l = a(l, y, p, h, t[e + 14], 15, -1416354905), 
        h = a(h, l, y, p, t[e + 5], 21, -57434055), p = a(p, h, l, y, t[e + 12], 6, 1700485571), 
        y = a(y, p, h, l, t[e + 3], 10, -1894986606), l = a(l, y, p, h, t[e + 10], 15, -1051523), 
        h = a(h, l, y, p, t[e + 1], 21, -2054922799), p = a(p, h, l, y, t[e + 8], 6, 1873313359), 
        y = a(y, p, h, l, t[e + 15], 10, -30611744), l = a(l, y, p, h, t[e + 6], 15, -1560198380), 
        h = a(h, l, y, p, t[e + 13], 21, 1309151649), p = a(p, h, l, y, t[e + 4], 6, -145523070), 
        y = a(y, p, h, l, t[e + 11], 10, -1120210379), l = a(l, y, p, h, t[e + 2], 15, 718787259), 
        h = a(h, l, y, p, t[e + 9], 21, -343485551), p = n(p, i), h = n(h, c), l = n(l, f), 
        y = n(y, g);
        return [ p, h, l, y ];
    }
    function f(t) {
        var r, e = "", n = 32 * t.length;
        for (r = 0; r < n; r += 8) e += String.fromCharCode(t[r >> 5] >>> r % 32 & 255);
        return e;
    }
    function g(t) {
        var r, e = [];
        for (e[(t.length >> 2) - 1] = void 0, r = 0; r < e.length; r += 1) e[r] = 0;
        var n = 8 * t.length;
        for (r = 0; r < n; r += 8) e[r >> 5] |= (255 & t.charCodeAt(r / 8)) << r % 32;
        return e;
    }
    function p(t) {
        var r, e, n = "";
        for (e = 0; e < t.length; e += 1) r = t.charCodeAt(e), n += "0123456789abcdef".charAt(r >>> 4 & 15) + "0123456789abcdef".charAt(15 & r);
        return n;
    }
    function h(t) {
        return unescape(encodeURIComponent(t));
    }
    function l(t) {
        return function(t) {
            return f(c(g(t), 8 * t.length));
        }(h(t));
    }
    function y(t, r) {
        return function(t, r) {
            var e, n, i = g(t), o = [], u = [];
            for (o[15] = u[15] = void 0, i.length > 16 && (i = c(i, 8 * t.length)), e = 0; e < 16; e += 1) o[e] = 909522486 ^ i[e], 
            u[e] = 1549556828 ^ i[e];
            return n = c(o.concat(g(r)), 512 + 8 * r.length), f(c(u.concat(n), 640));
        }(h(t), h(r));
    }
    return r ? e ? y(r, t) : p(y(r, t)) : e ? l(t) : p(l(t));
}, module.exports = t;